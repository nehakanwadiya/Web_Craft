import React, { useState } from 'react';
import './App.css';

function App() {
  const [bill, setBill] = useState('');
  const [tip, setTip] = useState('');
  const [people, setPeople] = useState(1);
  const [currency, setCurrency] = useState('INR');

  const totalTip = (bill * tip) / 100;
  const totalAmount = parseFloat(bill) + totalTip;
  const splitAmount = people > 0 ? totalAmount / people : 0;

  const formatCurrency = (value) => {
    if (isNaN(value)) return '';
    return value.toLocaleString('en-IN', {
      style: 'currency',
      currency: currency,
      minimumFractionDigits: 2,
    });
  };

  const backgroundStyle = {
    backgroundImage: `url(${process.env.PUBLIC_URL + '/background.jpg'})`,
    backgroundSize: 'cover',
    backgroundPosition: 'center',
    backgroundRepeat: 'no-repeat',
    minHeight: '100vh',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    fontFamily: 'Segoe UI, Tahoma, sans-serif',
  };

  return (
    <div style={backgroundStyle}>
      <div className="app-wrapper">
        <h1>Split Now! 💸</h1>

        <label>Bill Amount</label>
        <input
          type="number"
          value={bill}
          onChange={(e) => setBill(e.target.value)}
          placeholder="Enter bill amount"
        />

        <label>Tip Percentage (%)</label>
        <input
          type="number"
          value={tip}
          onChange={(e) => setTip(e.target.value)}
          placeholder="Enter tip percent"
        />

        <label>No. of People 👥</label>
        <input
          type="number"
          value={people}
          onChange={(e) => setPeople(e.target.value)}
          min="1"
        />

        <label>Select Currency</label>
        <select value={currency} onChange={(e) => setCurrency(e.target.value)}>
          <option value="INR">₹ Indian Rupee</option>
          <option value="USD">$ US Dollar</option>
          <option value="EUR">€ Euro</option>
          <option value="GBP">£ British Pound</option>
          <option value="JPY">¥ Japanese Yen</option>
        </select>

        <div className="result-box">
          <p><strong>Total Tip:</strong> {formatCurrency(totalTip)}</p>
          <p><strong>Total Amount:</strong> {formatCurrency(totalAmount)}</p>
          <p><strong>Each Person Pays:</strong> {formatCurrency(splitAmount)}</p>
        </div>
      </div>
    </div>
  );
}

export default App;
