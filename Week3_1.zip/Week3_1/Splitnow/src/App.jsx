import React from 'react';
import SplitNow from './components/SplitNow';

function App() {
  return <SplitNow />;
}

export default App;
