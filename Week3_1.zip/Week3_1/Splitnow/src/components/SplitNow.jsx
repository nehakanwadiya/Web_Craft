import React, { useState } from 'react';
import '../splitnow.css'; // adjust path if needed

function SplitNow() {
  const [bill, setBill] = useState('');
  const [tip, setTip] = useState('');
  const [people, setPeople] = useState('');

  const calculateSplit = () => {
    const billAmount = parseFloat(bill) || 0;
    const tipAmount = parseFloat(tip) || 0;
    const numPeople = parseInt(people) || 1;

    const total = billAmount + (billAmount * tipAmount) / 100;
    return (total / numPeople).toFixed(2);
  };

  return (
    <div
      style={{
        backgroundImage: "url('/background.jpg')",
        backgroundSize: "cover",
        backgroundPosition: "center",
        minHeight: "100vh",
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
      }}
    >
      <div className="app-wrapper">
        <h1>💸 SplitNow</h1>

        <label>Bill Amount</label>
        <input
          type="number"
          placeholder="Enter bill amount"
          value={bill}
          onChange={(e) => setBill(e.target.value)}
        />

        <label>Tip %</label>
        <input
          type="number"
          placeholder="Enter tip percentage"
          value={tip}
          onChange={(e) => setTip(e.target.value)}
        />

        <label>Number of People</label>
        <input
          type="number"
          placeholder="Enter number of people"
          value={people}
          onChange={(e) => setPeople(e.target.value)}
        />

        <div className="result-box">
          Each person pays: ₹{calculateSplit()}
        </div>
      </div>
    </div>
  );
}

export default SplitNow;
